# IA na prática: Acelerando o desenvolvimento e garantindo a qualidade com um fluxo de trabalho automatizado por IA

Este repositório contém um protótipo que demonstra como usar GitHub Copilot para acelerar escrita de código e testes e GitHub Actions para automatizar CI.

Estrutura do projeto:
- src/: código da API e lógica de negócio
- scripts/: gerador de dados fictícios (faker)
- tests/: testes Jest
- .github/workflows/ci.yml: workflow de CI

Instruções rápidas:
1. Instale dependências: `npm ci`
2. Gere dados fictícios: `npm run generate-data`
3. Rode os testes: `npm test`
